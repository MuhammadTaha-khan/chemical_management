// declare module 'react-slick' {
//     const Slider: any;
//     export default Slider;
//   }
  