
"use client";
import React from 'react';
import Faq2 from '../components/Faq2'; // Adjust the path if necessary
import Navbar from '../components/Navbar';

const Faqtwo = () => {
  return (
    <div>
        <Navbar/>
      <Faq2 />
    </div>
  );
};

export default Faqtwo;